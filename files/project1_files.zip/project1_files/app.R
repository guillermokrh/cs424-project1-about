# Author: Guillermo Rojas Hernandez

# Shiny dashboard showing data from the 1854 Cholera outbreak in London.

# I followed this tutorial for information on how to make tabs:
# https://github.com/rstudio/shiny-examples/blob/master/087-crandash/ui.R

#libraries to include

library(shiny)
library(shinydashboard)
library(ggplot2)
library(lubridate)
library(DT)
library(jpeg)
library(grid)
library(leaflet)

######### Beginning of my own project

### Cholera Deaths
# Read in file
choleraDeaths <- read.table(file = "choleraDeaths2.tsv", sep = "\t", header = TRUE)

# Order Date Chronologically
choleraDeaths$OrderedDate <- dmy(choleraDeaths$Date)

# Add Column with Attack Totals
choleraDeaths$AttackTotals <- cumsum(choleraDeaths$Attack)

# Add Column with Death Totals
choleraDeaths$DeathTotals <- cumsum(choleraDeaths$Death)
choleraDeaths

### Naples Deaths
naplesDeaths <- read.table(file = "naplesCholeraAgeSexData2.tsv", sep = "\t", header = TRUE)

### UK Census
UKCensus1851 <- read.table(file = "UKcensus1851.csv", sep = ",", header = TRUE)

### Cholera Death Locations
choleraDeathLocations <- read.table(file = "choleraDeathLocations.csv", sep = ",", header = FALSE)
colnames(choleraDeathLocations) <- c("deaths","long", "lat")

### Cholera Pump Locations
choleraPumpLocations <- read.table(file = "choleraPumpLocations.csv", sep = ",", header = FALSE)
colnames(choleraPumpLocations) <- c("long", "lat")


#########




ui <- dashboardPage(
    dashboardHeader(title = "CS 424: Project 1"),
    dashboardSidebar(
      sidebarMenu(
        menuItem("Dashboard", tabName="dashboard"),
        menuItem("About", tabName="about")
      )
    ),
    dashboardBody(
      tabItems(
        tabItem("dashboard",
          fluidRow(
            box(title = "Cholera Deaths Table", solidHeader = TRUE, status = "primary", width = 6,
              dataTableOutput("choleraDeathsTable")
            ),
            box( title = "Cholera Attacks and Cholera Deaths", solidHeader = TRUE, status = "primary", width = 6,
                 plotOutput("choleraDeathsLineChart")
            )
          ),   
          fluidRow(
            box( title = "Naples Deaths Table", solidHeader = TRUE, status = "primary", width = 4,
              dataTableOutput("naplesDeathsTable")
            ),
            box( title = "Naples Male Deaths Bar Chart", solidHeader = TRUE, status = "primary", width = 4,
                 plotOutput("naplesMaleDeathsBarChart")
            ),
            box( title = "Naples Female Deaths Bar Chart", solidHeader = TRUE, status = "primary", width = 4,
                 plotOutput("naplesFemaleDeathsBarChart")
            )          
          ), 
          fluidRow(
            box( title = "UK Census 1851", solidHeader = TRUE, status = "primary", width = 1,
                 dataTableOutput("UKCensus1851Table")
            ),
            box( title = "UK Census Male Age Pie Chart", solidHeader = TRUE, status = "primary", width = 2,
                 plotOutput("UKCensusMaleAgePieChart")
            ),
            box( title = "UK Census Female Age Pie Chart", solidHeader = TRUE, status = "primary", width = 2,
                 plotOutput("UKCensusFemaleAgePieChart")
            ),
            box( title = "UK 1851 Census Male Age Bar Chart", solidHeader = TRUE, status = "primary", width = 3,
                 plotOutput("UKCensusMaleAgeBarChart")
            ),
            box( title = "UK 1851 Census Female Age Bar Chart", solidHeader = TRUE, status = "primary", width = 3,
                 plotOutput("UKCensusFemaleAgeBarChart")
            )
          ), 
      fluidRow(
        box(title = "John Snow Map", solidHeader = TRUE, status = "primary", width = 4,
            plotOutput("jpeg")
        ), 
        box(title = "Current Map of London with Water Pumps Labeled", solidHeader = TRUE, status = "primary", width = 4,
            leafletOutput("leaf")
        )
      )
     ), #end of tab item
     tabItem("about",
             a("Find out more about this project on the official website", href="https://guillermokrh.github.io/cs424-project1-about/")
      )
    ) # end of TabItems 
  ) # end of DashboardBody
) # end of DashboardPage

server <- function(input, output) {

# increase the default font size
theme_set(theme_grey(base_size = 18)) 

# Use ordered date column to order by chronological date
# Create a linechart of number of cholera attacks, deaths, total attacks, and total deaths
output$choleraDeathsLineChart <- renderPlot({
  
  ggplot(data = choleraDeaths) + 
    geom_line(mapping = aes(x = choleraDeaths$OrderedDate, y = choleraDeaths$Attack),color = "blue") + 
    geom_line(mapping = aes(x = choleraDeaths$OrderedDate, y = choleraDeaths$AttackTotals), color = "red") + 
    geom_line(mapping = aes(x = choleraDeaths$OrderedDate, y = choleraDeaths$Death), color = "orange") + 
    geom_line(mapping = aes(x = choleraDeaths$OrderedDate, y = choleraDeaths$DeathTotals), color = "black") +
    xlab("August 19th, 1854 - September 29th, 1854") +
    ylab("Number of People Affected")
})

output$choleraDeathsTable <- DT::renderDataTable(
  DT::datatable(
    {choleraDeaths},
    options = list(searching = FALSE, pageLength = 7, lengthChange = FALSE, order = list(list(4, 'asc'))
    ) 
  )
)

output$naplesDeathsTable <- DT::renderDataTable(
  DT::datatable(
    {naplesDeaths},
    options = list(searching = FALSE, pageLength = 7, lengthChange = FALSE, order = list(list(1, 'asc'))
    ) 
  )
)

output$UKCensus1851Table <- DT::renderDataTable(
  DT::datatable(
    {UKCensus1851},
    options = list(searching = FALSE, pageLength = 7, lengthChange = FALSE, order = list(list(1, 'asc'))
    ) 
  )
)

output$UKCensusMaleAgePieChart <- renderPlot({
    ggplot(data = UKCensus1851) + geom_bar(mapping= aes(x="", y=male, fill=age), width = 1, stat="identity", color='black') + coord_polar("y", start=0) +
    theme(axis.ticks=element_blank(),  
          axis.title=element_blank(), 
          axis.text.y=element_blank()) +
    scale_y_continuous(labels=NULL)
})

output$UKCensusFemaleAgePieChart <- renderPlot({
  ggplot(data = UKCensus1851) + geom_bar(mapping= aes(x="", y=female, fill=age), width = 1, stat="identity", color='black') + coord_polar("y", start=0) +
    theme(axis.ticks=element_blank(),  
    axis.title=element_blank(), 
    axis.text.y=element_blank()) +
    scale_y_continuous(labels=NULL)
})

# UK Census Male Age Bar chart
output$UKCensusMaleAgeBarChart <- renderPlot({
  
  ggplot(data = UKCensus1851) + geom_bar(mapping = aes(x = age, y = male), stat = "identity")
  
})

# UK Census Female Age Bar chart
output$UKCensusFemaleAgeBarChart <- renderPlot({
  
  ggplot(data = UKCensus1851) + geom_bar(mapping = aes(x = age, y = female), stat = "identity")
  
})

# Male Fatalities Bar Chart
# stat = "identity" plots the literal values in the male column

output$naplesMaleDeathsBarChart <- renderPlot({
  
  ggplot(data = naplesDeaths) + geom_bar(mapping = aes(x = age, y = male), stat = "identity")

})

# Female Fatalities Bar Chart
# stat = "identity" plots the literal values in the female column
output$naplesFemaleDeathsBarChart <- renderPlot({
  
  ggplot(data = naplesDeaths) + geom_bar(mapping = aes(x = age, y = female), stat = "identity")
  
})


# use DT to help out with the tables - https://datatables.net/reference/option/


# read in a jpeg map of the lab to show the room layout and plot some text on it
output$jpeg <- renderPlot({
    # read in a jpg image
    jp <- jpeg::readJPEG('snowMapRobinWilson.jpg')

    df <- data.frame(x = -0.143614:-0.131024, y = 51.509435:51.516758) # set the range to be 1 to 10 in x and y for the image

    ggplot(df, aes(x,y)) + geom_blank() + labs(x="", y = "") +
        annotation_custom(rasterGrob(jp, width=unit(1,"npc"), height=unit(1,"npc")), -Inf, Inf, -Inf, Inf) + 
    

      theme(axis.title.x=element_blank(), axis.text.x=element_blank(), axis.ticks.x=element_blank()) +
      theme(axis.title.y=element_blank(), axis.text.y=element_blank(), axis.ticks.y=element_blank())
})

# add a leaflet map and put a marker on it at the location of the lab
# while not overly useful this can ceratinly be expnded upon
output$leaf <- renderLeaflet({
    map <- leaflet()
    map <- addTiles(map)
    map <- setView(map, lng = -0.13793, lat = 51.513418, zoom = 15)
    map <- leaflet(data = choleraDeathLocations[1:250,]) %>% addTiles() %>% addCircleMarkers(~long, ~lat, popup = ~as.character(deaths), label = ~as.character(deaths), radius = 5, color='red')
    map <- addMarkers(map, lng = -0.136668, lat = 51.513341, popup = "Pump")
    map <- addMarkers(map, lng = -0.139586, lat = 51.513876, popup = "Pump")
    map <- addMarkers(map, lng = -0.139671, lat = 51.514906, popup = "Pump")
    map <- addMarkers(map, lng = -0.13163, lat = 51.512354, popup = "Pump")
    map <- addMarkers(map, lng = -0.133594, lat = 51.512139, popup = "Pump")
    map <- addMarkers(map, lng = -0.135919, lat = 51.511542, popup = "Pump")
    map <- addMarkers(map, lng = -0.133962, lat = 51.510019, popup = "Pump")
    map <- addMarkers(map, lng = -0.138199, lat = 51.511295, popup = "Pump")
    map
})


}

shinyApp(ui = ui, server = server)
